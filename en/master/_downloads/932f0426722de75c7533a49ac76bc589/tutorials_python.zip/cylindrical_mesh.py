"""
Cylindrical meshes
==================

Cylindrical meshes are variation on the tensor mesh. The are still defined by
a vector in each dimension, but those dimensions are now in cylindrical,
rather than cartesian coordinates.

"""
